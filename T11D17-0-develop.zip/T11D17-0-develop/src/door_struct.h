#ifndef SRC_DOOR_STRUCT_H_
#define SRC_DOOR_STRUCT_H_

struct door {
    int id;
    int status;
};

#endif  // SRC_DOOR_STRUCT_H_
